package com.sds.customer_service.dto;

public class DeliveryRequestDTO {

}
