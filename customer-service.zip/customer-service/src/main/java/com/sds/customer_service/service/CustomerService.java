package com.sds.customer_service.service;

import java.time.ZoneId;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sds.customer_service.domain.Customer;
import com.sds.customer_service.dto.CustomerDTO;
import com.sds.customer_service.repository.CustomerRepository;

import ch.qos.logback.core.util.StringUtil;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;

	public Customer createCustomer(CustomerDTO customerDTO) {
		Customer customer = new Customer();
		customer.setName(customerDTO.getName());
		customer.setEmail(customerDTO.getEmail());
		customer.setContactNumber(customerDTO.getContactNumber());
		customer.setCreatedAt(new Date().toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime());
		return customerRepository.save(customer);
	}

	public Customer getCustomer(Long id) {
		return customerRepository.getReferenceById(id);
	}

	public List<Customer> getCustomers() {
		return customerRepository.findAll();
	}
	
	
	public Customer updateCustomer(Long id,CustomerDTO customerDTO) {
		Customer customer = customerRepository.getReferenceById(id);
		if(!StringUtil.isNullOrEmpty(customerDTO.getName())) {
			customer.setName(customerDTO.getName());
		}
		if(customerDTO.getContactNumber()!=null) {
			customer.setContactNumber(customerDTO.getContactNumber());
		}
		if(!StringUtil.isNullOrEmpty(customerDTO.getEmail())) {
			customer.setEmail(customerDTO.getEmail());
		}
		return customerRepository.save(customer);
	}

}
