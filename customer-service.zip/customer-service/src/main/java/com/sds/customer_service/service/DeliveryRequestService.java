package com.sds.customer_service.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sds.customer_service.domain.DeliveryRequest;
import com.sds.customer_service.dto.DeliveryRequestDTO;

@Service
public class DeliveryRequestService {

	public DeliveryRequest createDeliveryRequest(DeliveryRequest deliveryRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	public DeliveryRequest getDeliveryRequest(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<DeliveryRequest> getallDeliveryRequest() {
		// TODO Auto-generated method stub
		return null;
	}

	public DeliveryRequest updateDeliveryRequest(Long id, DeliveryRequestDTO deliveryRequestDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean deleteDeliveryRequest(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
