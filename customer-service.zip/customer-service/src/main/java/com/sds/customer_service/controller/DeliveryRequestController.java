package com.sds.customer_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sds.customer_service.domain.DeliveryRequest;
import com.sds.customer_service.dto.DeliveryRequestDTO;
import com.sds.customer_service.service.DeliveryRequestService;

@RestController
@RequestMapping(path="/api/v1")
public class DeliveryRequestController {

	@Autowired
	DeliveryRequestService deliveryRequestService;
	
	@GetMapping("/deliveryRequest/{id}")
	public DeliveryRequest getDeliveryRequest(@PathVariable Long id) {
		return deliveryRequestService.getDeliveryRequest(id);
	}
	
	@PostMapping("/deliveryRequest")
	public DeliveryRequest createDeliveryRequest(@RequestBody DeliveryRequest deliveryRequest) {
		return deliveryRequestService.createDeliveryRequest(deliveryRequest);
	}
	
	@GetMapping("/deliveryRequest")
	public List<DeliveryRequest> getAllDeliveryRequest(){
		return deliveryRequestService.getallDeliveryRequest();
	}
	
	@PostMapping("/deliveryRequest/{id}")
	public DeliveryRequest updatqeDeliveryRequest(@PathVariable Long id, @RequestBody  DeliveryRequestDTO deliveryRequestDTO) {
		return deliveryRequestService.updateDeliveryRequest(id, deliveryRequestDTO);
	}
	
	@DeleteMapping("/deliveryRequest/{id}")
	public Boolean deleteDeliveryRequest(@PathVariable Long id) {
		return deliveryRequestService.deleteDeliveryRequest(id);
	}
}
